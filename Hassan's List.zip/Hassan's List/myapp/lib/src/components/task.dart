import 'package:flutter/material.dart';
import 'package:myapp/src/pages/index.dart';
import 'package:collection/collection.dart';

import 'package:myapp/auth/auth_state.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:teta_cms/teta_cms.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:auth_buttons/auth_buttons.dart';

class PageTask extends StatefulWidget {
  const PageTask({
    Key? key,
    this.name = '''Task''',
    this.id = '''62cafe062a876825769afdea''',
  }) : super(key: key);

  final String name;
  final String id;

  @override
  _StateTask createState() => _StateTask();
}

class _StateTask extends State<PageTask> {
  var datasets = <String, dynamic>{};
  int index = 0;

  @override
  void initState() {
    super.initState();

    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "Task",
      },
      isUserIdPreferableIfExists: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 24,
        top: 16,
        right: 24,
      ),
      child: Container(
        margin: EdgeInsets.zero,
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(
                width: 0,
                style: BorderStyle.none,
                color: Color(0xFF000000).withOpacity(1)),
            top: BorderSide(
                width: 0,
                style: BorderStyle.none,
                color: Color(0xFF000000).withOpacity(1)),
            right: BorderSide(
                width: 0,
                style: BorderStyle.none,
                color: Color(0xFF000000).withOpacity(1)),
            bottom: BorderSide(
                width: 0,
                style: BorderStyle.none,
                color: Color(0xFF000000).withOpacity(1)),
          ),
        ),
        child: Card(
          elevation: 1,
          color: Color(0xFFFFFFFF).withOpacity(1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
              bottomRight: Radius.circular(16),
              bottomLeft: Radius.circular(16),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 16,
                    top: 16,
                    right: 16,
                    bottom: 16,
                  ),
                  child: Text(
                    '''${widget.name}''',
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: Color(0xFF383838).withOpacity(1),
                        fontWeight: FontWeight.w600,
                        fontSize: 20,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    textDirection: TextDirection.ltr,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
